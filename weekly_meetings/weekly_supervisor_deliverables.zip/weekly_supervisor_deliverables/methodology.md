# Methodology

## Experimental Design

The study employed a fully balanced factorial experimental design in
which every city was paired with every mental health scenario and every
language model:

$$D = C \times S \times M$$

where $C$ denotes the set of cities, $S$ the set of mental health
scenarios, and $M$ the set of language models. With twenty cities, eight
scenarios, and seven language models, the complete experimental matrix
consisted of

$$|D| = 20 \times 8 \times 7 = 1,120$$

unique prompt--response combinations, each generated exactly once,
producing a balanced dataset that enabled direct comparison across
geographic locations while controlling for scenario and model identity.

Four independent variables were examined throughout the analysis:
geographic location (city and country); World Bank income category
(High, Upper-middle, Lower-middle, and Low income); WHO region (Africa,
Americas, Eastern Mediterranean, Europe, South-East Asia, and Western
Pacific); and language model identity. Language model identity was
included as a control variable because different LLMs may exhibit
distinct response styles and safety behaviours. The eight mental health
scenarios were additionally categorised into three predefined acuity
levels (Low, Moderate, and High) according to clinical severity, and
scenario acuity was incorporated as a covariate in the regression models.

The dependent variables were extracted automatically from each
AI-generated response using the rule-based NLP pipeline described in
Section 3.3. These included total response word count; specificity
score (telephone numbers, crisis short codes, and URLs); VADER sentiment
scores; binary indicators for references to professional, family,
community, and religious or spiritual support; and the presence of
crisis-service contact information.

To ensure that geographic context remained the only manipulated factor,
every prompt followed the same template: *"I live in \[City\],
\[Country\]. \[Mental health scenario\]."* Only the city, country, and
scenario text varied between experimental conditions. All model
parameters were held constant wherever possible, with the temperature
fixed at 0.0 to minimise stochastic variation and improve
reproducibility.

Figure [3.1](#fig:experimental_design){reference-type="ref"
reference="fig:experimental_design"} illustrates the overall
experimental design employed in the study.

<!-- FIX NEEDED: no image file has been supplied for this figure. Insert
     an <img src="./Figures/..." /> tag here once the diagram is available. -->
<figure id="fig:experimental_design" data-latex-placement="H">

<figcaption>Overview of the factorial experimental design used in the
study.</figcaption>
</figure>

## Dataset and Data Collection

The study evaluated 1,120 AI-generated responses collected from this
balanced design. The twenty cities were purposively selected, rather
than sampled at random, to ensure representation across all four World
Bank income categories and six WHO regions while maximising geographic,
economic, and cultural diversity. The selected cities are shown in
Table [3.1](#tab:cities){reference-type="ref" reference="tab:cities"}.

::: {#tab:cities}
  **Income Category**   **Cities**
  --------------------- ----------------------------------------------------
  High income           London, New York, Tokyo, Sydney, Riyadh
  Upper-middle income   Sao Paulo, Beijing, Johannesburg, Bogota, Belgrade
  Lower-middle income   Lagos, Mumbai, Cairo, Jakarta, Kyiv
  Low income            Kinshasa, Kabul, Kathmandu, Antananarivo, Damascus

  : Cities included in the experimental dataset by World Bank income
  category.
:::

Eight standardised mental health scenarios represented common
help-seeking situations spanning a range of clinical severity, including
loneliness, insomnia, anxiety, caregiver stress, panic attacks,
relationship breakdown, unemployment, and hopelessness, each assigned an
a priori acuity level (Low, Moderate, or High) before data collection.

The original dissertation proposal specified three proprietary models
(GPT-4o, Claude, and Gemini). During implementation this was revised
because of API cost constraints and model availability, and the final
study evaluated seven contemporary LLMs accessed through four providers:

- GPT-OSS 120B (Groq)

- Llama 3.3 70B Instruct (Groq)

- Qwen 3 32B (Groq)

- Llama 4 Scout 17B-16E Instruct (Groq)

- Gemma 4 26B A4B Instruct (Google AI Studio)

- Mistral Small 2506 (Mistral AI)

- NVIDIA Nemotron-3 Super 120B A12B (OpenRouter)

This modification increased the diversity of evaluated models and
strengthened comparisons between model families, although the findings
should be interpreted with respect to these seven models rather than the
proprietary systems originally proposed.

An automated Python pipeline generated the complete experimental matrix
by combining every city with every scenario and every language model,
and all prompts were submitted automatically using the respective model
APIs. For every generated response, the pipeline recorded accompanying
metadata: a unique matrix identifier, city, country, World Bank income
category, WHO region, scenario identifier and acuity level, language
model, provider, timestamp, and the complete response text.

The automated collection procedure ensured that each of the 1,120
experimental conditions was completed exactly once. All responses were
stored without manual editing or post-processing prior to feature
extraction, preserving the original outputs generated by each language
model and ensuring full reproducibility of the dataset.

## Pre-processing, Feature Extraction, and Statistical Analysis

All AI-generated responses underwent minimal pre-processing: cleaning
was limited to whitespace and line-break normalisation, and any visible
model reasoning or internal thinking blocks generated by reasoning
models were removed, since these do not form part of the user-facing
response. No other modifications were made to the response text.

Following pre-processing, a rule-based NLP pipeline combining
regular-expression matching, dictionary-based coding, sentiment
analysis, and response-level quantitative measures was applied to
extract structured features from each response.

Response length was calculated as the total number of
whitespace-delimited words. Regular expressions identified telephone
numbers, recognised emergency short codes, and URLs---short codes were
identified before applying the telephone-number pattern to avoid
double-counting---and the total count of these elements was combined
into a composite specificity score, representing the degree to which a
response contained concrete, actionable information.

Dictionary-based keyword matching identified references to four
categories of support (professional, family, community, and religious
or spiritual), each recorded as a binary variable indicating whether at
least one reference was present.

Sentiment analysis was performed using the Valence Aware Dictionary and
sEntiment Reasoner (VADER), which produces positive, neutral, negative,
and compound sentiment scores for each response. The compound score,
ranging from $-1$ to $+1$, was used as the principal sentiment measure
because it provides a single normalised estimate of emotional tone while
accounting for lexical intensity and contextual modifiers.

A heuristic fabrication indicator was also implemented to flag hedging
language associated with crisis-service recommendations (e.g. *"please
verify"*, *"check locally"*). This indicator does not verify the
factual accuracy of contact information but identifies instances where
the model explicitly signals uncertainty.

The extracted features were combined into a structured coding matrix,
transforming each free-text response into quantitative variables
suitable for statistical analysis, which proceeded in three stages.

First, descriptive statistics summarised the extracted features across
World Bank income categories, WHO regions, language models, and mental
health scenarios, using means, medians, and standard deviations for
continuous variables and frequencies and percentages for categorical
variables.

Second, unadjusted inferential analyses evaluated differences between
groups. Because several continuous outcomes were non-normally
distributed, Kruskal--Wallis H tests compared multiple groups, with
epsilon-squared ($\varepsilon^2$) as the effect size; binary outcomes
were analysed using chi-square tests with Cramér's $V$; and Spearman's
rank correlation ($\rho$) assessed monotonic relationships between
income category and continuous response characteristics. Where omnibus
tests were significant, Mann--Whitney U tests served as post hoc
comparisons, and the Benjamini--Hochberg false discovery rate (FDR)
correction was applied across all inferential analyses.

Finally, multivariable regression models evaluated whether observed
geographic differences remained after controlling for language model
identity and scenario severity. A linear mixed-effects model analysed
response word count, with city as a random intercept and scenario as an
additional variance component; a Bayesian logistic mixed-effects model
was fitted for the binary presence of crisis-service contact
information; and negative binomial regression models were used for
count outcomes (specificity score and religious-support references),
with scenario as a fixed effect and standard errors clustered by city.
These adjusted models formed the primary basis for answering the
research questions, as they simultaneously accounted for geographic
location, model identity, and scenario severity while accommodating the
distributional characteristics of each outcome.

## Reliability, Validity, Limitations, and Ethics

Several measures maximised reliability and validity. The experimental
design was fully standardised, with every prompt following the same
template while varying only city, country, and scenario, minimising the
influence of prompt wording. The rule-based NLP pipeline applied
identical extraction rules to all 1,120 responses; to assess its
robustness, a second independently developed rule set was applied to
four key binary indicators. Agreement was assessed using Cohen's kappa:
crisis-service contacts, family support, and religious support showed
almost perfect agreement ($\kappa > 0.90$), while professional support
showed substantial agreement ($\kappa \approx 0.68$), reflecting greater
linguistic variation in how models refer to professional healthcare
services. This assessment represents a robustness check of the
automated coding rules rather than conventional human inter-rater
reliability.

Data quality checks confirmed that every combination of city, scenario,
and language model appeared exactly once. An early version of the
telephone-number extraction pattern incorrectly matched certain
four-digit sequences and occasionally double-counted emergency short
codes; the expressions were revised and revalidated across the complete
dataset before feature extraction.

Construct validity was strengthened by selecting response
characteristics directly aligned with the research questions---response
length, specificity, crisis-service references, the four support
categories, and sentiment---which collectively captured multiple
dimensions of response quality, actionability, and cultural framing.
Established statistical procedures and regression models controlling
for model identity and scenario severity further improved internal
validity.

Several limitations should nonetheless be acknowledged. The
crisis-service reference categories were developed from publicly
available directories rather than the WHO Mental Health Atlas, so the
analyses evaluate whether models provide crisis-service information
rather than whether every contact detail is factually correct; the
fabrication indicator is similarly a heuristic measure of uncertainty
rather than independent verification. The geographic sampling strategy
selected one representative city per country, so findings should not be
read as representing all locations within a country. Finally, the study
analysed single-turn interactions collected during one period, and as
models continue to evolve through ongoing updates, the findings should
be read as a snapshot of behaviour at the time of data collection rather
than a permanent characteristic of the systems evaluated.

No human participants were involved in this research, and no personal
or identifiable information was collected; the unit of analysis was
AI-generated text produced through publicly available APIs. Ethical
approval was obtained from Middlesex University before data collection
commenced, and any response excerpts reproduced in this dissertation are
presented solely to illustrate observed patterns of model behaviour,
not to evaluate or criticise individual providers.

To support transparency and reproducibility, the complete research
pipeline---prompt generation, response collection, NLP feature
extraction, statistical analysis, and figure generation---was
implemented in Python, with all scripts, configuration files, and
processed datasets retained to enable the analytical workflow to be
reproduced from the original raw response data.

