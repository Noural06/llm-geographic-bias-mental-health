# Source-data audit — original response files

Seven files, `AI. Responces/`, audited against `combined_dataset.csv`.

## The good news first

| Check | Result |
|---|---|
| Row count | 1,120 = 7 models x 160, matches exactly |
| Factorial completeness | All 1,120 cells filled (7 x 20 x 8), exactly one response each |
| Response-text integrity | Every original response present exactly once — **no silent loss** |
| Duplicate responses | 0 — all 1,120 texts distinct |
| Failed API calls | 0 (`status` = success throughout, no error messages) |
| Blank responses | 0 |
| Reasoning-block leakage | 160 Qwen responses contain `<think>`; all properly terminated, all stripped cleanly, none empty afterwards (min 300 words post-strip) |

The design is intact and the combining step lost nothing. This is worth
stating plainly given the earlier missing-ID scare.

---

## Issue 1 — `matrix_id` is broken in the exported CSV

Three separate defects in the source files:

| File | Problem |
|---|---|
| `responses_llama4_scout_160.csv` | no `matrix_id` column |
| `responses_nemotron_160.csv` | no `matrix_id` column |
| `responses_gemma_4_26b_a4b_it_160.csv` | contains Llama 3.3's ID set verbatim — all 160 IDs end `_groq_llama` |

Net effect in `combined_dataset.csv`: **320 nulls, and another 320 rows sharing
160 IDs across two different models.** Only 640 of 1,120 IDs are unique.

**The notebook's loader already handles this correctly** — Section 3 discards the
supplied IDs, rebuilds from `city + scenario_id + model_name`, and asserts
uniqueness. The problem is that `combined_dataset.csv` is a **pre-repair export**.
Anyone starting from that file — a reviewer, a GitHub user, or a future you —
inherits the defect.

### It was already causing a wrong number

Three places used `n=('matrix_id', 'count')`. Pandas `.count()` skips nulls, so
the reported *n* in the descriptive tables was:

| Income group | Reported n | True n | Missing |
|---|---|---|---|
| High | 200 | 280 | 80 |
| Low | 200 | 280 | 80 |
| Lower-Middle | 200 | 280 | 80 |
| Upper-Middle | 200 | 280 | 80 |

Exactly the same failure mode as the original missing-ID incident: a nullable
column used as a counter, failing quietly rather than loudly.

**Fixed:** all counts now use `('response_text', 'size')`, which counts rows.
`combined_dataset_REPAIRED.csv` is exported with rebuilt IDs plus a `source_file`
provenance column. A provenance audit (notebook Section 2b) now runs these checks
on every execution and writes `Table_00_ProvenanceAudit.csv`.

---

## Issue 2 — Nemotron responses are systematically truncated

**143 of 160** Nemotron-3-Super-120B responses end mid-word.

| Model | n | Median words | Min | Truncated |
|---|---|---|---|---|
| GPT-OSS 120B | 160 | 1,039 | 236 | 0 |
| Gemma 4 26B | 160 | 965 | 544 | 0 |
| Qwen 3 32B | 160 | 942 | 541 | 0 |
| Llama 4 Scout | 160 | 400 | 162 | 2 |
| Mistral Small | 160 | 377 | 153 | 1 |
| Llama 3.3 70B | 160 | 352 | 149 | 0 |
| **Nemotron-3-Super** | **160** | **155** | **13** | **143** |

Examples of where they stop:

> Cairo, S6, 13 words — `...you've been struggling with insomnia for several months—it`
> Antananarivo, S2, 14 words — `...been feeling anxious and overwhelmed for several weeks—that`

This is a collection artefact, almost certainly a `max_tokens` ceiling set too low
for that provider, not a property of the model. It matters because it depresses
every "does the response contain X" outcome for Nemotron — the response ended
before it could contain anything.

### Does it threaten the findings? No, and it is testable

Truncation is **not patterned by geography**, which is the only thing that would
manufacture a spurious geographic effect:

- Across all models, truncation by income category: chi-square **p = 0.99**
- Within Nemotron alone: chi-square **p = 0.62**
- Nemotron word count by income: Kruskal-Wallis **p = 0.098**

Because model identity is a control in all three confirmatory models, truncation
is absorbed as a model fixed effect. And dropping Nemotron entirely **strengthens**
both findings:

| | All 7 models | Excluding Nemotron |
|---|---|---|
| H1, High vs Low | +0.614 (p < 0.001) | **+0.637** (p < 0.001) |
| H2, Established line vs none | +0.347 (p < 0.001) | **+0.407** (p < 0.001) |
| H1 city-mean Spearman rho | 0.848 | 0.814 |

So including Nemotron is the **conservative** choice — it attenuates rather than
inflates. A full leave-one-model-out table is in `Table_15_LeaveOneModelOut.csv`.

### What to say in the write-up

> Responses were collected from seven models. One (Nemotron-3-Super-120B-A12B)
> returned truncated output in 143 of 160 cases, consistent with a token limit
> applied during collection. Truncation was unrelated to city income category
> (chi-square p = 0.99) and is absorbed by the model fixed effect in all
> confirmatory models. Sensitivity analyses excluding this model produce larger
> effect estimates in the same direction; the reported estimates are therefore
> conservative.

Do **not** report per-model comparisons involving Nemotron as though they measure
model behaviour. Its low actionability score (1.075 against 2.703 for the other
six) measures the token limit, not the model.

---

## Recommended next steps

1. **Use `combined_dataset_REPAIRED.csv`** as the canonical dataset going forward,
   and push the source ZIP to GitHub alongside it so the chain is reproducible
   end to end.
2. **Consider recollecting Nemotron** with a higher token limit if there is time.
   It is one API run and would remove the largest remaining caveat. If not, the
   disclosure above is sufficient — the sensitivity analysis carries it.
3. **Keep the provenance audit in the pipeline.** It is cheap and it has now caught
   two defects that neither the row-count check nor the inter-rule kappa did.
