# Response to supervision — final

## All 7 items complete

| # | Item | Status |
|---|---|---|
| 1 | Manually code ~100 stratified responses | Done — 112 coded + 100 for H3 |
| 2 | Report precision/recall/F1; revise or discard weak features | Done |
| 3 | Finalise three hypotheses | Done |
| 4 | Retain response- and city-level data | Done |
| 5 | One controlled model per outcome | Done |
| 6 | Three core figures | Done |
| 7 | Upload to GitHub | Done |

---

## Validated outcome measures

| Outcome | What it measures | F1 | Status |
|---|---|---|---|
| `actionability_v2` (0–5) | Concrete, followable steps: crisis contact, professional referral in a recommendation, emergency escalation, immediate-action framing, named coping step | **0.764** | ✓ |
| `localisation_v2c` (0–2) | Location-specific guidance: explicit location reference, named local institution, contact present | **0.750** | ✓ |
| `religious_rec` (binary) | Religious or spiritual support recommended inside a directive sentence, bullet, or table row | **0.889** [0.678, 0.934] | ✓ |

The localisation measure was built under two constraints — text-readable and monotone —
because a prior specification that violated the monotone constraint produced a directionally
reversed result that human validation caught. Two automated coding rules agreed at
κ = 0.93–0.99 without detecting it. This is documented as a methodological contribution.

---

## Confirmatory models

### H1 — Actionability ~ income category (ref = Low)

| Income | Coef | 95% CI | p |
|---|---|---|---|
| Lower-Middle | +0.321 | [0.152, 0.490] | 0.0002 |
| Upper-Middle | +0.446 | [0.277, 0.615] | < 0.0001 |
| High | **+0.639** | [0.470, 0.808] | < 0.0001 |

Mixed-effects model, city random intercept, controls: model identity, scenario.
Survives n = 20 city-level test (Spearman ρ = 0.824, p < 0.001) and all 7 model exclusions.

### H2 — Localisation ~ crisis-service availability (ref = None documented)

| Service | Coef | 95% CI | p |
|---|---|---|---|
| Limited/NGO | +0.251 | [0.054, 0.449] | 0.012 |
| Established national line | **+0.353** | [0.159, 0.547] | < 0.001 |

### H3 — Religious framing ~ WHO region (ref = AFR)

Firth penalised logistic regression (EUR: 2 of 168 positive responses — near-separation).

| Region | OR | 95% CI | p | Raw rate |
|---|---|---|---|---|
| AFR (reference) | 1.000 | — | — | 24.1% |
| EMR | 1.139 | [0.690, 1.883] | 0.61 | 25.9% |
| SEAR | 0.210 | [0.094, 0.469] | < 0.001 | 8.0% |
| WPR | 0.140 | [0.071, 0.279] | < 0.001 | 5.8% |
| AMR | 0.056 | [0.020, 0.156] | < 0.001 | 2.4% |
| EUR | 0.030 | [0.008, 0.111] | < 0.001 | 1.2% |

AFR and EMR are statistically indistinguishable and sit far above all other regions.

---

## Unplanned finding: crisis-contact fabrication

| Documented service | Numbers offered | Visibly synthetic | Rate |
|---|---|---|---|
| Established national line | 277 | 3 | 1.1% |
| Limited/NGO | 181 | 29 | 16.0% |
| None documented | 32 | 11 | **34.4%** |

Floor estimate — pattern-matching only catches visibly synthetic numbers (555 blocks,
sequential digits, repeated digits). The true rate is higher.

---

## Source-data notes

- `combined_dataset_REPAIRED.csv` has rebuilt unique IDs — use this, not the original
- Nemotron-3-Super is truncated in 143/160 responses; unrelated to geography (χ² p = 0.99);
  excluding it strengthens both findings — retaining it is the conservative choice
- Nepal reclassified to "Established national line" (WHO-documented); 4 other countries
  re-verified this week; 15 of 20 carry earlier desk-research classifications

---

## What remains before publication

1. Complete crisis-service verification for all 20 countries (15 outstanding)
2. Add no-location control condition — one API run
3. Expand city count beyond 20
